import numpy as np
import matplotlib.pyplot as plt

#reading from regression_data.txt and appends in a reg_data list
file=open("regression_data.txt","r")
reg_data= list()
for x in file:
    reg_data.append(x)
file.close()

#splits sizes and weights in one line and makes them a list
array_length = len(reg_data)
for i in range(array_length):
    reg_data[i]= reg_data[i].split()

reg_data.pop(0)#deleting first line in txt
reg_data.pop()#deleting empty line at the end of txt

#definition of arrays named x and y
x = np.array([], dtype=int)
y = np.array([], dtype=int)
s = list()
w = list()


#puts splitted data in lists
for i in range(len(reg_data)):
    s.append(int(reg_data[i][0]))
    w.append(int(reg_data[i][1]))

#puts the data which in lists to arrays
for i in range(len(s)):
    x = np.append(x, s[i])
for i in range(len(w)):
    y = np.append(y, w[i])

#default values for Gradient Descent
m = 0
b = 0
L  = 0.0001
iteration = 1000
n = x.size

#gradient descent iterations
for i in range(len(x)):
    y_pred = m * x + b
    D_m = (-2/n) * sum(x * (y - y_pred))
    D_b = (-2/n) * sum(y - y_pred)
    m = m - L*D_m
    b = b - L*D_b
    print(m , b , i)

